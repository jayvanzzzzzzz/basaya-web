import {
  onAuthStateChanged,
  signOut,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

import { auth, db } from "../js/firebase.js";
import { state } from "../js/state.js";
import { rememberAccount } from "../js/recent-accounts.js";
import { $, setLoading, shell, toast } from "../js/helpers.js";
import { renderRoute } from "./router.js";
// Every form's required fields show their own message instead of the browser bubble.
import "../js/field-errors.js";
import { confirmTeacherLogout } from '../js/teacher-logout.js';

$("#logout-button").addEventListener("click", async (event) => {
  const button = event.currentTarget;
  if (button.disabled) return;
  button.disabled = true;
  try {
    if (!await confirmTeacherLogout({ eyebrow: 'Your admin workspace', description: 'You’ll return to the sign-in page. Sign in again whenever you’re ready to manage your school.' })) return;
    rememberAccount(auth.currentUser, state.profile || {});
    sessionStorage.setItem("basayaSignedOut", "true");
    try {
      await signOut(auth);
      window.location.replace("../index.html");
    } catch (error) {
      sessionStorage.removeItem("basayaSignedOut");
      console.error("Admin sign-out failed:", error);
      toast("Could not sign out. Please try again.");
    }
  } finally {
    button.disabled = false;
    button.focus({ preventScroll: true });
  }
});
window.addEventListener("hashchange", renderRoute);
window.addEventListener("pageshow", () => {
  if (sessionStorage.getItem("basayaSignedOut") === "true") {
    window.location.replace("../index.html");
  }
});

onAuthStateChanged(auth, async (user) => {
  setLoading(true);
  state.user = user;
  state.profile = null;

  if (!user) {
    window.location.replace("../index.html");
    return;
  }

  try {
    const profile = await getDoc(doc(db, "users", user.uid));
    if (!profile.exists() || profile.data().role !== "admin") {
      await signOut(auth);
      window.location.replace("../index.html");
      return;
    }
    state.profile = profile.data();
    shell("admin-summary", "Admin");
    await renderRoute();
  } catch (error) {
    console.error(error);
    await signOut(auth);
    window.location.replace("../index.html");
  } finally {
    setLoading(false);
  }
});
